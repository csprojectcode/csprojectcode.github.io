clear;clc;
close all;
base_path='C:/Users/hsicv/Documents/whispers/';
videos={'ball';'basketball';'board';'book';'bus';'bus2';'campus';'car';'car2';'car3';'card';'coin';'coke';'drive';'excavator';'face';'face2';'forest';'forest2';'fruit';'hand';'kangaroo';'paper';'pedestrain';'pedestrian2';'player';'playground';'rider1';'rider2';'rubik';'student';'toy1';'toy2';'trucker';'worker'};% videos={'ball';'basketball';'board1';'board2';'book1';'book2';'boy';'bus';'bus2';'campus';'car';'car2';'car3';'car4';'car5';'card';'coin';'coke';'drive';'excavator';'face';'face2';'forest';'forest2';'fruit';'grass2';'green';'hand1';'kangroo';'kangroo2';'palyground';'paper';'pedestrain';'pedestrain2';'rubit';'student';'toylight';'worker';'yellowtoy1';'yellowtoy2';'yellowtoylight'};
OPs = zeros(numel(videos),1);
FPSs = zeros(numel(videos),1);
videoNum=numel(videos);
distance_rec=zeros(videoNum,50);
PASCAL_rec=zeros(videoNum,50);
average_cle_rec=zeros(videoNum,50);
learning_rate =0.0023;
for vid = 1:videoNum
    close all;
    video_path = [base_path '/' videos{vid}];
    [seq, ground_truth] = load_video_info(video_path);
    seq.VidName = videos{vid};
    st_frame = 1;
    en_frame = seq.len;
    seq.st_frame = st_frame;
    seq.en_frame = en_frame;
    gt_boxes = [ground_truth(:,1:2), ground_truth(:,1:2) + ground_truth(:,3:4) - ones(size(ground_truth,1), 2)];
    
    % Run MHT- main function
    
    results = run_MHT(seq, video_path, learning_rate);
    results.gt = gt_boxes;
    pd_boxes = results.res;
    [distance_rec(vid,:),PASCAL_rec(vid,:),average_cle_rec(vid,:),~,~]= computeMetric2(pd_boxes,ground_truth);
    FPSs = results.fps;
    result=matfile(sprintf(strcat(videos{vid},'trackingMHT.mat'),'writable',true);
    result.results=results;
    result.distance_rec=distance_rec;
    result.PASCAL_rec=PASCAL_rec;
    result.average_cle_rec=average_cle_rec;
end
save(strcat('trackingMHT','.mat'),'FPSs','PASCAL_rec','average_cle_rec','distance_rec');




