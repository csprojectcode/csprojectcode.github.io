function DataCube=X2Cube(I, block, bandNumber)
% for VIS: block=4;bandNumber=16;
% for NIR: block=5;bandNumber=25;
% for RedNIR: block=4;bandNumber=16; Please drop drop out the last
% band which contains only zero values. DataCube=DataCube(:,:,1:15);
I=double(I);

% black=double(imread('black.bmp'));
% I=I(:,:,1)-black(:,:,1);
[x,y]=size(I);
DataCube = im2colstep(I',[block block],[block,block]);
sz=[y/block, x/block  bandNumber];
DataCube=reshape(DataCube',sz);
DataCube=permute(DataCube,[2,1,3]);

end
