1. install environment : see in environment_config
2. train the BAE-Net: see in train
3. test the BAE-Net: see in test